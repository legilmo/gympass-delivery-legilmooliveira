package br.com.gympass.racemonitoring.exception;

public class ReadFileException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ReadFileException(String message) {
		super(message);
	}

}
