package br.com.gympass.racemonitoring.constants;

public class Constants {
	public static final String HORA_HEADER = "Hora";

}
