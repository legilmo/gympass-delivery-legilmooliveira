# gympass-delivery-legilmooliveira
Repositório do projeto que monitora uma corrida.
Passo a passo:

	1 - Acesse o shell do windows.
	2 - Acesse a pasta aonde foi feito o clone do repositório.
	3 - Vá ate a pasta bin: cd bin/
	4 - Execute o comando substituindo <PATH_ARQUIVO> pelo caminho onde 
	    está o arquivo de input:  java -jar race-monitoring.jar <PATH_ARQUIVO>
